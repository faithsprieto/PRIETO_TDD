package com.example.tddactivity

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_list.*
import androidx.test.espresso.idling.CountingIdlingResource

class ListActivity : AppCompatActivity(), ItemsAdapter.OnItemClickListener {

    companion object {
        const val EXTRA_COUNT = "extra_count"
        const val EXTRA_ITEM = "extra_item"
    }

    private lateinit var itemsAdapter: ItemsAdapter
    private val loader: ItemsLoader by lazy {
        // Use Application injection if available
        (application as? TddApplication)?.itemsLoader ?: TimerItemsLoader()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        itemsAdapter = ItemsAdapter(this)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = itemsAdapter

        val count = intent?.getIntExtra(EXTRA_COUNT, 0) ?: 0
        loader.load(count) { items ->
            runOnUiThread {
                itemsAdapter.submitList(items)
            }
        }
    }

    override fun onItemClick(item: ItemModel) {
        val intent = Intent(this, DetailActivity::class.java).apply {
            putExtra(EXTRA_ITEM, item.text)
        }
        startActivity(intent)
    }
}
