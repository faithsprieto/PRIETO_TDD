package com.example.tddactivity

import androidx.test.espresso.idling.CountingIdlingResource
import java.util.*
import kotlin.concurrent.schedule

class TimerItemsLoader(
    private val idlingResource: CountingIdlingResource? = null
) : ItemsLoader {

    private val timer = Timer()

    override fun load(count: Int, callback: (List<ItemModel>) -> Unit) {
        idlingResource?.increment()
        val items = mutableListOf<ItemModel>()
        // Schedule tasks every 1 second to simulate async incremental loading.
        // For simplicity we schedule a single timer that adds items with delay steps.
        var delay = 0L
        for (i in 1..count) {
            delay += 1000L
            timer.schedule(delay) {
                val text = "Item $i"
                items.add(ItemModel(text))
                if (items.size == count) {
                    idlingResource?.decrement()
                    callback(items.toList())
                }
            }
        }

        // Edge case: count == 0 -> return immediately
        if (count == 0) {
            idlingResource?.decrement()
            callback(emptyList())
        }
    }
}
