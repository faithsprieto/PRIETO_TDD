package com.example.tddapp

interface ItemsLoader {
    fun load(count: Int, callback: (List<ItemModel>) -> Unit)
}
