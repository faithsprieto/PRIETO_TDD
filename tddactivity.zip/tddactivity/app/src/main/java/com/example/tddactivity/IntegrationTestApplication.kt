package com.example.tddactivity

import androidx.test.espresso.idling.CountingIdlingResource

class IntegrationTestApplication : TddApplication() {
    override val itemsLoader: ItemsLoader by lazy {
        object : ItemsLoader {
            override fun load(count: Int, callback: (List<ItemModel>) -> Unit) {
                // return quickly without delay for Robolectric integration test
                val items = (1..count).map { ItemModel("Item $it") }
                callback(items)
            }
        }
    }
}
