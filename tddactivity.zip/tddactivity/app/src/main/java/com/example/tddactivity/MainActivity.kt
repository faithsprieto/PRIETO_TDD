package com.example.tddactivity

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.* // or use findViewById

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        goButton.setOnClickListener {
            val text = numberEditText.text.toString()
            val count = text.toIntOrNull() ?: 0
            val intent = Intent(this, ListActivity::class.java).apply {
                putExtra(ListActivity.EXTRA_COUNT, count)
            }
            startActivity(intent)
        }
    }
}
