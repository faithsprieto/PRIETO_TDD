package com.example.tddactivity

import android.app.Application
import androidx.test.espresso.idling.CountingIdlingResource

open class TddApplication : Application() {

    // instantiate production instances; tests can subclass and override
    open val idlingResource: CountingIdlingResource = EspressoIdlingResource.idlingResource
    open val itemsLoader: ItemsLoader by lazy { TimerItemsLoader(idlingResource) }
    open val textProvider: TextProvider by lazy { TextProvider(this) }
}
