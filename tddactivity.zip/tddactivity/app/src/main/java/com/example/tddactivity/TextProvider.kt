package com.example.tddactivity

import android.content.Context

class TextProvider(private val context: Context) {
    fun getItemText(position: Int): String {
        // returns "Item x"
        return "Item $position"
    }

    fun getYouClickedText(itemText: String): String {
        return "You clicked $itemText"
    }
}
