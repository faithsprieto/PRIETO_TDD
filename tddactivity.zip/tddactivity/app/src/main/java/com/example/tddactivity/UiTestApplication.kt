package com.example.tddactivity

import androidx.test.espresso.idling.CountingIdlingResource

class UiTestApplication : TddApplication() {
    override val itemsLoader: ItemsLoader by lazy {
        object : ItemsLoader {
            override fun load(count: Int, callback: (List<ItemModel>) -> Unit) {
                // quickly produce items but still notify idling resource correctly
                EspressoIdlingResource.idlingResource.increment()
                val items = (1..count).map { ItemModel("Item $it") }
                EspressoIdlingResource.idlingResource.decrement()
                callback(items)
            }
        }
    }
}
