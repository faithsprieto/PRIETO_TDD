package com.example.tddaactivity

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class ItemModel(val text: String) : Parcelable
