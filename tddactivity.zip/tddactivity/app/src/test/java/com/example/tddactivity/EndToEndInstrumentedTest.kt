package com.example.tddactivity

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.rule.ActivityTestRule
import com.example.tddapp.robots.MainActivityRobot
import com.example.tddapp.robots.ListActivityRobot
import com.example.tddapp.robots.DetailActivityRobot
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import androidx.test.filters.LargeTest
import androidx.test.espresso.intent.Intents
import androidx.test.espresso.intent.matcher.IntentMatchers.hasComponent

@RunWith(AndroidJUnit4::class)
@LargeTest
class EndToEndInstrumentedTest {

    @get:Rule
    val activityRule = ActivityTestRule(MainActivity::class.java, true, true)

    @Test
    fun fullFlow_testUsingRobots() {
        Intents.init()
        try {
            val main = MainActivityRobot()
            main.enterNumber("3").clickGo()
            // ListActivity should launch; UI tests rely on Application class injecting UiTestApplication
            val list = ListActivityRobot()
            list.checkItemCount(3).clickItemAt(1)
            val detail = DetailActivityRobot()
            detail.checkDisplayedText("You clicked Item 2")
        } finally {
            Intents.release()
        }
    }
}
