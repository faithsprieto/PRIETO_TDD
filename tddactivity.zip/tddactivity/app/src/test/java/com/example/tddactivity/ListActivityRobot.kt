package com.example.tddactivity.robots

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.contrib.RecyclerViewActions
import androidx.test.espresso.matcher.ViewMatchers.*
import com.example.tddapp.ItemsAdapter
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.recyclerview.widget.RecyclerView
import androidx.test.espresso.action.ViewActions.click

class ListActivityRobot {
    fun checkItemCount(expected: Int): ListActivityRobot {
        // We will check by attempting to scroll to last position
        onView(withId(com.example.tddapp.R.id.recycler))
            .perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(expected - 1))
        return this
    }

    fun clickItemAt(position: Int): ListActivityRobot {
        onView(withId(com.example.tddapp.R.id.recycler))
            .perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(position, click()))
        return this
    }
}
