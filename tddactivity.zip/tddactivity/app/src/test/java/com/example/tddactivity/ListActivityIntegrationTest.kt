package com.example.tddactivity

import android.content.Intent
import androidx.test.core.app.ApplicationProvider
import org.junit.Test
import org.robolectric.Robolectric
import org.robolectric.annotation.Config
import org.junit.Assert.assertEquals

@Config(application = IntegrationTestApplication::class)
class ListActivityIntegrationTest {

    @Test
    fun `ListActivity loads items and clicking opens DetailActivity`() {
        val intent = Intent(ApplicationProvider.getApplicationContext(), ListActivity::class.java)
        intent.putExtra(ListActivity.EXTRA_COUNT, 3)
        val controller = Robolectric.buildActivity(ListActivity::class.java, intent).setup()
        val activity = controller.get()

        // Wait (Robolectric runs tasks synchronously for our IntegrationTestApplication loader)
        val recycler = activity.findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.recycler)
        val itemCount = recycler.adapter?.itemCount ?: 0
        assertEquals(3, itemCount)

        // Simulate click on item 2
        val vh = recycler.findViewHolderForAdapterPosition(1)
        if (vh != null) {
            vh.itemView.performClick()
        } else {
            // Force bind then click
            val adapter = recycler.adapter!!
            val view = adapter.createViewHolder(recycler, 0).itemView
            adapter.bindViewHolder(adapter.createViewHolder(recycler,0), 1)
            view.performClick()
        }

        val nextIntent = org.robolectric.Shadows.shadowOf(activity).nextStartedActivity
        assertEquals(DetailActivity::class.java.name, nextIntent.component?.className)
        assertEquals("Item 2", nextIntent.getStringExtra(ListActivity.EXTRA_ITEM))
    }
}
