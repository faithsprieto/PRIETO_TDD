package com.example.tddactivity

import android.content.Intent
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.robolectric.Robolectric
import org.robolectric.annotation.Config

@Config(application = IntegrationTestApplication::class)
class MainActivityIntegrationTest {

    @Test
    fun `MainActivity sends count to ListActivity`() {
        val activityController = Robolectric.buildActivity(MainActivity::class.java).setup()
        val activity = activityController.get()
        val editText = activity.findViewById<android.widget.EditText>(R.id.numberEditText)
        editText.setText("4")
        val button = activity.findViewById<android.widget.Button>(R.id.goButton)
        button.performClick()

        // Grab the next started activity intent from Robolectric shadows
        val nextIntent = org.robolectric.Shadows.shadowOf(activity).nextStartedActivity
        assertEquals(ListActivity::class.java.name, nextIntent.component?.className)
        assertEquals(4, nextIntent.getIntExtra(ListActivity.EXTRA_COUNT, -1))
    }
}
