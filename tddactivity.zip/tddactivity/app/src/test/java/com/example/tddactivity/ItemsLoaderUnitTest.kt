package com.example.tddactivity

import androidx.test.espresso.idling.CountingIdlingResource
import org.junit.Assert.assertEquals
import org.junit.Test
import org.mockito.kotlin.mock
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class ItemsLoaderUnitTest {

    @Test
    fun `TimerItemsLoader loads requested number of items`() {
        val idling = CountingIdlingResource("test")
        val loader = TimerItemsLoader(idling)
        val latch = CountDownLatch(1)
        var result: List<ItemModel>? = null

        // For unit tests we don't want to wait long; load 0 to get immediate callback:
        loader.load(0) { items ->
            result = items
            latch.countDown()
        }

        latch.await(1, TimeUnit.SECONDS)
        assertEquals(0, result?.size)
    }
}
