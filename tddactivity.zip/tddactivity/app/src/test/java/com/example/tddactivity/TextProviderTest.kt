package com.example.tddactivity

import android.content.Context
import org.junit.Assert.assertEquals
import org.junit.Test
import org.mockito.kotlin.mock

class TextProviderTest {

    private val mockContext: Context = mock()

    @Test
    @org.junit.experimental.categories.Category(SmallTest::class)
    fun `getItemText returns correct format`() {
        val provider = TextProvider(mockContext)
        val text = provider.getItemText(3)
        assertEquals("Item 3", text)
    }

    @Test
    fun `getYouClickedText returns correct message`() {
        val provider = TextProvider(mockContext)
        val res = provider.getYouClickedText("Item 2")
        assertEquals("You clicked Item 2", res)
    }
}
