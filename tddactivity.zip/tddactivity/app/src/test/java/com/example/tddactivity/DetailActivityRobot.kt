package com.example.tddactivity.robots

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.espresso.assertion.ViewAssertions.matches

class DetailActivityRobot {
    fun checkDisplayedText(expected: String) {
        onView(withId(com.example.tddapp.R.id.resultText)).check(matches(withText(expected)))
    }
}
