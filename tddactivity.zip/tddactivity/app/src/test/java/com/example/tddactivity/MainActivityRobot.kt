package com.example.tddactivity.robots

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.*
import androidx.test.espresso.matcher.ViewMatchers.*

class MainActivityRobot {
    fun enterNumber(n: String): MainActivityRobot {
        onView(withId(com.example.tddapp.R.id.numberEditText)).perform(clearText(), typeText(n), closeSoftKeyboard())
        return this
    }

    fun clickGo(): MainActivityRobot {
        onView(withId(com.example.tddapp.R.id.goButton)).perform(click())
        return this
    }
}
