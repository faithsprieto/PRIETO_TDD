package com.example.tddactivity

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.*
import androidx.test.espresso.matcher.ViewMatchers.*

class Activity1Robot {

    fun enterNumber(number: String): Activity1Robot {
        onView(withId(R.id.editTextNumber)).perform(typeText(number), closeSoftKeyboard())
        return this
    }

    fun clickNext(): Activity1Robot {
        onView(withId(R.id.buttonNext)).perform(click())
        return this
    }
}
