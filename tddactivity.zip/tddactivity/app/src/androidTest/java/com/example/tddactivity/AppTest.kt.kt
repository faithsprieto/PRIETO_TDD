package com.example.tddactivity

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.rule.ActivityTestRule

import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class AppTest {

    @Rule
    @JvmField
    val rule = ActivityTestRule(Activity1::class.java)

    @Test
    fun fullFlowTest() {
        val act1 = Activity1Robot()
        val act2 = Activity2Robot()
        val act3 = Activity3Robot()

        // Activity 1
        act1.enterNumber("3")
        act1.clickNext()

        // Activity 2
        act2.assertItemCount(3)
        act2.clickItem(1)   // click "Item 2"

        // Activity 3
        act3.assertClickedText("You clicked Item 2")
    }
}
