package com.example.tddactivity

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.*

class Activity3Robot {

    fun assertClickedText(text: String): Activity3Robot {
        onView(withId(R.id.textViewClicked)).check(matches(withText(text)))
        return this
    }
}
