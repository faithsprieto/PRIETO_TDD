package com.example.tddactivity

import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.contrib.RecyclerViewActions
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.recyclerview.widget.RecyclerView
import androidx.test.espresso.assertion.ViewAssertions.matches

class Activity2Robot {

    fun assertItemCount(expected: Int): Activity2Robot {
        onView(withId(R.id.recyclerView))
            .check(RecyclerViewItemCountAssertion(expected))
        return this
    }

    fun clickItem(position: Int): Activity2Robot {
        onView(withId(R.id.recyclerView))
            .perform(
                RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(
                    position, click()
                )
            )
        return this
    }
}
